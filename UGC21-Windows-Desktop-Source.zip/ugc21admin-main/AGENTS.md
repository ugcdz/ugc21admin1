<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- Store website repository settings on each site and publish only its published apps to a validated public JSON path; this keeps multi-site updates isolated and prevents arbitrary source writes.
- Keep binaries private and deliver free downloads through a status-checked redirect; paid/licensed binaries require an authorization flow before public delivery.
- Use authenticated server functions with verified owner identity for GitHub calls; workspace credentials must never reach browsers.
- Store every content category in the existing owned app catalog with an explicit content type; this preserves site isolation and upload delivery.
- License requests use short-lived signed, single-use form challenges; approval generates a high-entropy bearer code checked against the published item before private downloads.
- Keep promo codes scoped to owned sites and consume usage atomically with the database function; external checkout integration must call an authenticated owner-authorized path.
