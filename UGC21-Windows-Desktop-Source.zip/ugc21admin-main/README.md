# Ugc Twenty One Studio

اريد انشاء تطبيق خاص حيث لا يضهر يكون  لادارة مواقع UGC 21 — تطوير تطبيقات وأمن سيبراني مثل هاذا موقع خاص بي

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4278ffb0-b8ca-426a-9dd8-fbedb06ad28c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
