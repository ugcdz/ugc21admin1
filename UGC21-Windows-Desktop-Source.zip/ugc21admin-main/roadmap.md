# Work
- [ ] Add site purposes and typed content management.
- [ ] Add license request inbox, approval codes, and protected downloads.
- [ ] Add per-site promo codes with discount and usage limits.
- [ ] Connect NOVA DIGITAL; waiting for its website and GitHub URLs.
- [x] Link GitHub and inspect the UGC 21 website.
- [x] Add app file uploads and safe download delivery; owner upload/save/readback verified.
- [x] Add per-site repository settings and catalog synchronization; real GitHub writes verified.
- [x] Connect the existing website catalog; existing application visible on live website.
- [ ] Publish the management app and resend the catalog with its permanent URL; requires user's publishing request. Live public image currently fails through the preview address; public download not verified.