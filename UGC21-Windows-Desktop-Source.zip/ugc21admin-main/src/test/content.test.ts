import { describe, expect, it } from "vitest";
import { defaultContentType, promoSchema, promoAvailable } from "@/lib/content";
describe("site content and promo rules", () => {
  it("defaults PDF websites to books", () => expect(defaultContentType("books")).toBe("book"));
  it("defaults music websites to songs", () => expect(defaultContentType("music")).toBe("song"));
  it("accepts a named 25 percent code with three uses", () => expect(promoSchema.parse({ code: "nova25", discount_percent: 25, max_uses: 3 })).toEqual({ code: "NOVA25", discount_percent: 25, max_uses: 3 }));
  it("rejects discounts above 100 percent", () => expect(promoSchema.safeParse({ code: "NOVA", discount_percent: 101, max_uses: 3 }).success).toBe(false));
  it("requires a positive whole usage limit", () => { expect(promoSchema.safeParse({ code: "NOVA", discount_percent: 25, max_uses: 0 }).success).toBe(false); expect(promoSchema.safeParse({ code: "NOVA", discount_percent: 25, max_uses: 1.5 }).success).toBe(false); });
  it("stops a code at its usage limit", () => expect(promoAvailable({ active: true, used_count: 3, max_uses: 3 })).toBe(false));
  it("allows a code before its usage limit", () => expect(promoAvailable({ active: true, used_count: 2, max_uses: 3 })).toBe(true));
});