import { describe, expect, it } from "vitest";
import { catalogPath, publicApp, repositoryName } from "@/lib/site-catalog";
import type { Tables } from "@/integrations/supabase/types";

const app = { id: "app-1", title: "UGC", license: "free", file_path: "owner/app.apk", images: [], notes: "private", user_id: "owner" } as unknown as Tables<"apps">;
describe("owned site catalog", () => {
  it("accepts the owner's GitHub repository", () => expect(repositoryName("https://github.com/ugcdz/ugc-21-app-and-ideas")).toBe("ugcdz/ugc-21-app-and-ideas"));
  it("rejects writes outside the public JSON catalog", () => expect(() => catalogPath("public/../src/main.json")).toThrow());
  it("provides file downloads for free applications", () => expect(publicApp(app, "https://ugc.example").download_url).toBe("https://ugc.example/api/public/app-media?id=app-1&download=1"));
  it("does not expose paid application files", () => expect(publicApp({ ...app, license: "paid" }, "https://ugc.example").download_url).toBeNull());
  it("does not expose licensed application files", () => expect(publicApp({ ...app, license: "licensed" }, "https://ugc.example").download_url).toBeNull());
  it("keeps owner notes private", () => expect(publicApp(app, "https://ugc.example")).not.toHaveProperty("notes"));
  it("provides a license request link for books", () => expect(publicApp({ ...app, content_type: "book", license: "licensed" }, "https://ugc.example").license_request_url).toBe("https://ugc.example/license?app=app-1"));
  it("does not leak licensed external links", () => expect(publicApp({ ...app, file_path: null, license: "licensed", download_url: "https://private.example/book.pdf" }, "https://ugc.example").download_url).toBeNull());
});